# liquor Classification > 2025-07-04 1:48pm
https://universe.roboflow.com/test-e809o/liquor-classification

Provided by a Roboflow user
License: CC BY 4.0

